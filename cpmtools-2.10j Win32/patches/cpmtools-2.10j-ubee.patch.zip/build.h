#define APPVER "cpmtools-2.10j_ubee"
